package Tests.test.contoller;

import Tests.test.view.Forms;
import javax.swing.JOptionPane;
import sw.Cliente;
import sw.DepositoRetiro;
import sw.OperacionesMatematicas;
import sw.OperacionesMatematicas_Service;

public class AdministrarControl {

    private Forms view;
    private OperacionesMatematicas_Service servicio = new OperacionesMatematicas_Service();
    private OperacionesMatematicas transaccion = servicio.getOperacionesMatematicasPort();

    DepositoRetiro retiro = new DepositoRetiro();
    Cliente cliente = new Cliente();

    public AdministrarControl(Forms view) {
        this.view = view;
        view.setVisible(true);
        view.getLblmnsjregistro().setVisible(false);
        view.getPnlInicioSession().setVisible(true);
        view.getPnlregistro().setVisible(false);
        view.getDepositoRetiro().setVisible(false);

    }

    public void inicioControl() {
        view.getBtninicio().addActionListener(l -> login());
        view.getBtnregistrar().addActionListener(l -> registro());
        view.getBtnSalir().addActionListener(l -> regresaLogin());
        view.getBtninicio().addActionListener(l -> mostrarDeposito());

        view.getBtnaqui().addActionListener(l -> registrar());
        view.getBtnRegistro1().addActionListener(l -> {
            if (view.getRdRetiro().isSelected()) {
                retiro();
            } else if (view.getRdDeposito().isSelected()) {
                deposito();
            }
        });

    }

    public void regresaLogin() {
        view.getPnlregistro().setVisible(false);
        view.getPnlInicioSession().setVisible(true);

    }

    private void login() {
        String user = view.getTxtusuarioinicio().getText();
        String clave = view.getTxtclaveinicio().getText();

        if (!user.isEmpty() && !clave.isEmpty()) {
            cliente.setUser(user);
            cliente.setPass(clave);
            cliente = transaccion.login(cliente);

            if (cliente.getUser() != null) {
                JOptionPane.showMessageDialog(null, "Loggeo exitoso");
                System.out.println(cliente.getSaldo());
                view.getLbluser().setText(cliente.getUser());
                view.getTxtsaldo().setText("" + cliente.getSaldo());

                mostrarDeposito();
            } else {
                JOptionPane.showMessageDialog(null, "Nombre de usuario/contraseña incorrectos");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Existen campos vacios");
        }
    }

    private void registrar() {
        view.getPnlregistro().setVisible(true);
        view.getPnlInicioSession().setVisible(false);
    }

    private void registro() {
        String user = "";
        String pass = "";
        String repiteclave = "";
        int saldo = 0;

        user = view.getTxtuserregistro().getText();
        pass = view.getTxtclaveregistro().getText();
        repiteclave = view.getTxtrepiteclaveregistro().getText();
        saldo = Integer.parseInt(view.getSpnsaldoregistro().getValue().toString());

        if (!user.isEmpty() || !pass.isEmpty() || !repiteclave.isEmpty()) {
            System.out.println("Campos Llenos");

            if (pass.equals(repiteclave)) {
                cliente.setUser(user);
                cliente.setPass(pass);
                cliente.setSaldo(saldo);

                if (transaccion.registro(cliente)) {
                    view.getLblmnsjregistro().setVisible(true);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Contraseñas Incorrectas");
            }

        } else {
            JOptionPane.showMessageDialog(null, "Rellene todos los campos");
        }
    }

    private void mostrarDeposito() {

        view.getDepositoRetiro().setVisible(true);
        view.getPnlInicioSession().setVisible(false);
    }

    private void retiro() {
        retiro.setCantidad(Integer.parseInt(view.getTxtvalor().getText()));
        retiro.setUser(cliente.getUser());

    }

    private void deposito() {
        retiro.setCantidad(Integer.parseInt(view.getTxtvalor().getText()));
        retiro.setUser(cliente.getUser());
        DepositoRetiro resultadoDeposito = transaccion.depositar(retiro);
    }

}
