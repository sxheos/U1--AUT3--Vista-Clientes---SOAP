/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tests.test;

import Tests.test.contoller.AdministrarControl;
import Tests.test.view.Forms;
import sw.OperacionesMatematicas;
import sw.OperacionesMatematicas_Service;

/**
 *
 * @author sandr
 */
public class TestWS {

    public static void main(String[] args) {
//        OperacionesMatematicas_Service service = new OperacionesMatematicas_Service(); 
//        OperacionesMatematicas cliente = service.getOperacionesMatematicasPort();
//
//        cliente.loggin("sandrita", "123");
//
//        // Operaciones matemáticas
//        double resultadoSuma = cliente.suma(5.0, 3.0);
//        double resultadoResta = cliente.resta(5.0, 3.0);
//        double resultadoMultiplicacion = cliente.multiplicacion(5.0, 3.0);
//        double resultadoDivision = cliente.division(6.0, 2.0);
//
//        System.out.println("Resultado de la suma: " + resultadoSuma);
//        System.out.println("Resultado de la resta: " + resultadoResta);
//        System.out.println("Resultado de la multiplicación: " + resultadoMultiplicacion);
//        System.out.println("Resultado de la división: " + resultadoDivision);
//
//        // Fórmula cuadrática
//        String resultadoFormulaCuadratica = cliente.formulaCuadratica(1.0, -5.0, 6.0);
//        System.out.println("Resultado de la fórmula cuadrática: " + resultadoFormulaCuadratica);
//    }

        Forms vista = new Forms();
        AdministrarControl controller = new AdministrarControl(vista);
        controller.inicioControl();
    }
}
